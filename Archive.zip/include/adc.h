// void adc_init();
// uint8_t playback_delay = 0;
// // void adc(void);