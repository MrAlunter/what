void print_rand(uint16_t *value);
uint32_t next(void);
int sequence(void);