void spi_init();
void spi_write(uint8_t b);