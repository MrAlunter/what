#include <avr/io.h>
#include <util/delay.h>
#include <stdio.h>
#include <stdint.h>
#include <avr/interrupt.h>
#include "uart.h"
#include "timer.h"
#include "buzzer.h"
#include "spi.h"
#include "buttons.h"

void adc_init()
{

    ADC0.CTRLA = ADC_ENABLE_bm;                                      // Enable ADC
    ADC0.CTRLB = ADC_PRESC_DIV2_gc;                                  // /2 clock prescaler
    ADC0.CTRLC = (4 << ADC_TIMEBASE_gp) | ADC_REFSEL_VDD_gc;         // Need 4 CLK_PER cycles @ 3.3 MHz for 1us, select VDD as ref
    ADC0.CTRLE = 64;                                                 // Sample duration of 64
    ADC0.CTRLF = ADC_FREERUN_bm;                                     // Free running, left adjust result
    ADC0.MUXPOS = ADC_MUXPOS_AIN2_gc;                                // Select AIN2 (potentiomenter R1)
    ADC0.COMMAND = ADC_MODE_SINGLE_8BIT_gc | ADC_START_IMMEDIATE_gc; // Select 12-bit resolution, single-ended
};

// void adc(void)
// {

//     uart_init();     // Initialize the UART (serial port)
//     adc_init();      // Initialize ADC
//     char buffer[10]; // Buffer for string output
//     while (1)
//     {
//         playback_delay = (1750 * ADC0.RESULT >> 8) + 250; // Calculate the playback delay
//     }
// }
